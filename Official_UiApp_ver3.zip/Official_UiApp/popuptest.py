from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QDialog, QWidget

class Popup(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Popup")
        layout = QVBoxLayout()
        layout.addWidget(QPushButton("Close Popup"))
        self.setLayout(layout)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Main Window")
        layout = QVBoxLayout()
        layout.addWidget(QPushButton("Show Popup"))
        self.central_widget = QWidget()
        self.central_widget.setLayout(layout)
        self.setCentralWidget(self.central_widget)

        layout.itemAt(0).widget().clicked.connect(self.show_popup)

    def show_popup(self):
        popup = Popup()
        popup.exec_()

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()
