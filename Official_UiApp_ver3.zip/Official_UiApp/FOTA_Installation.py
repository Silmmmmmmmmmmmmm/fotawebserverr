import sys
from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QProgressBar, QVBoxLayout, QLabel, QMainWindow, QFileDialog, QFormLayout
from PyQt5.QtCore import Qt
from PyQt5 import uic
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer, pyqtSignal, pyqtSlot
from FOTA_InstallTECU import  FOTA_TransferFileToAdapter, client_send_and_receive

class install2TECU_Popup(QDialog):
    valueUpdated = pyqtSignal(str)
    def __init__(self, filepath, isNewFWInstall):
        super().__init__()
        uic.loadUi(r'dialog.ui', self)
        self.progressbar_2.setValue(0)
        self.confirmBtn.setEnabled(False)
        self.confirmBtn.clicked.connect(self.close)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_progress)
        self.timer.start(100)
        
        self.filepath = filepath
        self.isNewFWInstall = isNewFWInstall
    def update_progress(self):
        serverAddress = ('192.168.0.123', 7)
        print("isnew????????", self.isNewFWInstall)
        print("filepath????????", self.filepath)
        
        if self.isNewFWInstall == "NO":
            FOTA_TransferFileToAdapter(self.filepath)
            isFileTransferring = True
            while isFileTransferring:
                msg = "REQ_SEQ_STATUS"
                if msg != '':  # Validate the message
                    response = client_send_and_receive(serverAddress, msg)  # Send the command to the server and receive the response
                    msg = ''
                    if response is not None:
                        print('Data received:', response)
                        if response == "RESP_EXT_SESS_SUCCESS":
                            current_value = "RESP_EXT_SESS_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(15)
                        elif response == "RESP_SEC_ACCESS_B_SUCCESS" :
                            current_value = "RESP_SEC_ACCESS_B_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(20)
                        elif response == "RESP_SET_PROGMD_SUCCESS" :
                            current_value = "RESP_SET_PROGMD_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(22)
                        elif response == "RESP_PROG_SESS_SUCCESS" :
                            current_value = "RESP_PROG_SESS_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(25)
                        elif response == "RESP_SEC_ACCESS_A_SUCCESS" :
                            current_value = "RESP_SEC_ACCESS_A_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(30)
                        elif response == "RESP_IDWRITE_REPAIR_SUCCESS" :
                            current_value = "RESP_IDWRITE_REPAIR_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(32)
                        elif response == "RESP_IDWRITE_PROG_SUCCESS" :
                            current_value = "RESP_IDWRITE_PROG_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(35)
                        elif response == "RESP_ERASE_APP_SUCCESS" :
                            current_value = "RESP_ERASE_APP_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(40)
                        elif response == "RESP_TESTER_PRESENT_SUCCESS" :
                            current_value = "RESP_TESTER_PRESENT_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(41)
                        elif response == "RESP_REQ_TRANSFER_SUCCESS" :
                            current_value = "RESP_REQ_TRANSFER_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(42)
                        elif response == "RESP_TRANSFER_APP_SUCCESS" :
                            current_value = "RESP_TRANSFER_APP_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(55)
                        elif response == "RESP_EXIT_TRANSFER_SUCCESS" :
                            current_value = "RESP_EXIT_TRANSFER_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(90)
                        elif response == "RESP_READ_DTC_SUCCESS" :
                            current_value = "RESP_READ_DTC_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(95)
                        elif response == "RESP_RID_CHECK_SUCCESS" :
                            current_value = "RESP_RID_CHECK_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(97)
                        elif response == "RESP_DEFAULT_SESSION":
                            current_value = "RESP_RID_CHECK_SUCCESS"
                            self.current_install_status.setText(f"{current_value}")
                            self.progressbar_2.setValue(100)
                            isFileTransferring = False
                    else:
                        print('Invalid or empty message.')       
        response_new = client_send_and_receive(serverAddress, "DEFAULT_SS")
        current_value = "COMPLETED"
        self.current_install_status.setText(f"{current_value}")
        self.isNewFWInstall = "YES"
        self.valueUpdated.emit(self.isNewFWInstall)
        if self.progressbar_2.value() >= 100:
            self.progressbar_2.setValue(100)
            self.confirmBtn.setEnabled(True)
            self.timer.stop()
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    dialog = install2TECU_Popup()
    dialog.exec_()
