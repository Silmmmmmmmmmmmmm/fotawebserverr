import sys
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton
from PyQt5.QtCore import pyqtSlot, QFile, QTextStream, QThread, pyqtSignal
import time 
from sidebar_ui import Ui_MainWindow
from FOTA_readServerMessages import *
from FOTA_checkPackageServer import *
# RECEIVED_MESSAGES = 0
# CONNECTION_STRING = "HostName=FotaWebserver.azure-devices.net;DeviceId=raspberry4;SharedAccessKey=bsmqCOwvRpNENe4O5Z4wubiz80TM9jxZhRlCsK1bsRs="
# RECEIVED_MESSAGE_DATA = ""
# RECEIVED_DATA = ""
isNewServerMsg = False
baseServerFileList = []
isNewSwAvai = "NO"

# Sends a message to the server and receives the response over TCP.
def client_send_and_receive(server_address, message):
    global isNewServerMsg
    bufferSize = 1024
    timeout = 5  # Set a timeout value of 5 seconds
    TCPClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Create a TCP socket
    TCPClient.settimeout(timeout)  # Set socket timeout
    TCPClient.connect(server_address)
    print('Connect successfully. Server IP address: {0}. Port: {1}'.format(server_address[0], server_address[1]))
    TCPClient.sendall(message.encode('utf-8'))
    print('Message is sent.')
    try:
        print('Receiving the response from the server')
        data = TCPClient.recv(bufferSize)
        data = data.decode('utf-8')
        isNewServerMsg = False
        return data
    except socket.timeout:
        print('Timeout occurred/No response from the server.')
        return None
    finally:
        TCPClient.close()
        
def TCP_Send(serverAddress, msg):
    response = client_send_and_receive(serverAddress, msg)  # Send the command to the server and receive the response
    msg = ''
    if response is not None:
        print('Data received:', response)

        
def serverMessageHandler(message):
    global RECEIVED_MESSAGES
    global RECEIVED_MESSAGE_DATA
    global isNewServerMsg
    global RECEIVED_DATA
    RECEIVED_MESSAGES += 1
    print("")
    print("Message received:")
    # print data from both system and application (custom) properties
    print("MsgType: ",str(vars(message)['message_id']),"\n")  
    RECEIVED_MESSAGE_DATA = vars(message)['data']
    RECEIVED_DATA = RECEIVED_MESSAGE_DATA.decode('utf-8')
    isNewServerMsg = True
        
class rb_fota_listenServerReq_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
            print ("Starting the Python IoT Hub C2D Messaging device sample...")
            # Instantiate the client
            client = IoTHubDeviceClient.create_from_connection_string(CONNECTION_STRING)
            serverAddress = ('192.168.0.123', 7)
            print ("Waiting for C2D messages")
            try:
                # Attach the handler to the client
                while True:
                    client.on_message_received = serverMessageHandler
                    if isNewServerMsg == True:
                        TCP_Send(serverAddress,RECEIVED_DATA)
                    time.sleep(1)
            except KeyboardInterrupt:
                print("IoT Hub C2D Messaging device sample stopped")
            finally:
                # Graceful exit
                print("Shutting down IoT Hub Client")
                client.shutdown()
            time.sleep(1)
            self.signal.emit()
class rb_fota_checkPackageServer_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()
    
    def run(self):
        global baseServerFileList
        global isNewSwAvai
        baseServerFileList = get_first_file_list()
        print(baseServerFileList)
        while True:
            checkServerContainerResult = get_file_from_cloud(baseServerFileList)
            if checkServerContainerResult[-1] == "YES":
                baseServerFileList = checkServerContainerResult[0]
            time.sleep(1)
            self.signal.emit()
class rb_fota_sendServerRes_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
            time.sleep(15)
            self.signal.emit()
class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
        self.rb_fota_checkPackageServer_thread = rb_fota_checkPackageServer_thread()
        self.rb_fota_sendServerRes_thread = rb_fota_sendServerRes_thread()
        
        self.rb_fota_listenServerReq_thread.signal.connect(self.on_listenServerReq_thread)
        self.rb_fota_checkPackageServer_thread.signal.connect(self.on_checkPakageServer_thread)
        self.rb_fota_sendServerRes_thread.signal.connect(self.on_sendServerRes_thread)
        
        self.rb_fota_listenServerReq_thread.start()
        self.rb_fota_checkPackageServer_thread.start()
        self.rb_fota_sendServerRes_thread.start()
        
        self.ui.icon_only_widget.hide()
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.home_btn_2.setChecked(True)
    @pyqtSlot()
    def on_listenServerReq_thread(self):
        print("Signal received from cyclic thread1!")
    @pyqtSlot()
    def on_checkPakageServer_thread(self):
        print("Signal received from cyclic thread2!")
    @pyqtSlot()
    def on_sendServerRes_thread(self):
        print("Signal received from cyclic thread3!")
    ## Function for searching
    def on_search_btn_clicked(self):
        self.ui.stackedWidget.setCurrentIndex(5)
        search_text = self.ui.search_input.text().strip()
        if search_text:
            self.ui.label_9.setText(search_text)

    ## Function for changing page to user page
    def on_user_btn_clicked(self):
        self.ui.stackedWidget.setCurrentIndex(6)

    ## Change QPushButton Checkable status when stackedWidget index changed
    def on_stackedWidget_currentChanged(self, index):
        btn_list = self.ui.icon_only_widget.findChildren(QPushButton) \
                    + self.ui.full_menu_widget.findChildren(QPushButton)
        
        for btn in btn_list:
            if index in [5, 6]:
                btn.setAutoExclusive(False)
                btn.setChecked(False)
            else:
                btn.setAutoExclusive(True)
            
    ## functions for changing menu page
    def on_home_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(0)
    
    def on_home_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(0)

    def on_dashborad_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_dashborad_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_orders_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_orders_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_products_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_products_btn_2_toggled(self, ):
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_customers_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)

    def on_customers_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    ## loading style file
    # with open("style.qss", "r") as style_file:
    #     style_str = style_file.read()
    # app.setStyleSheet(style_str)

    ## loading style file, Example 2
    style_file = QFile("style.qss")
    style_file.open(QFile.ReadOnly | QFile.Text)
    style_stream = QTextStream(style_file)
    app.setStyleSheet(style_stream.readAll())


    window = MainWindow()
    window.show()

    sys.exit(app.exec())



