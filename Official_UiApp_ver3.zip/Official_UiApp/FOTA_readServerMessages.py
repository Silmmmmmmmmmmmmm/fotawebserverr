import time
from azure.iot.device import IoTHubDeviceClient
import socket
from time import sleep

RECEIVED_MESSAGES = 0
CONNECTION_STRING = "HostName=FotaWebserver.azure-devices.net;DeviceId=raspberry4;SharedAccessKey=bsmqCOwvRpNENe4O5Z4wubiz80TM9jxZhRlCsK1bsRs="
RECEIVED_MESSAGE_DATA = ""
RECEIVED_DATA = ""
