import time
from azure.iot.device import IoTHubDeviceClient
import socket
from time import sleep

RECEIVED_MESSAGES = 0
CONNECTION_STRING = "HostName=fotadevices.azure-devices.net;SharedAccessKeyName=service;SharedAccessKey=rUYh1yPGbG7duLPE/m1QFxNLii2PP5GvbYhKfOQG6KE="
RECEIVED_MESSAGE_DATA = ""
RECEIVED_DATA = ""
