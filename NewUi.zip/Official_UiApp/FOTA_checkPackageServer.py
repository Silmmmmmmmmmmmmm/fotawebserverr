from azure.storage.blob import BlobServiceClient
from azure.iot.device import IoTHubDeviceClient
import time
from threading import Thread
import os
import socket
# ket noi toi iot hub
CONNECTION_STRING = CONNECTION_STRING = "HostName=OTADeviceHub.azure-devices.net;DeviceId=OTAmaster;SharedAccessKey=L7Yzdmqz1TZlgkGeQjOpG5l/DnoVWLfEOcY12CEeKEg="

# Kết nối tới Azure Storage Account
connection_string = "DefaultEndpointsProtocol=https;AccountName=otastorage2;AccountKey=0e77Bl3w45EqddjDN0t23MK0d69vIi8BrqTQMjioUSVrJC9e+jloKmPQZqxslK9VZQd+KVLXQ84s+AStTJF47w==;EndpointSuffix=core.windows.net"
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

# Tên container cần kiểm tra
container_name = "otas"
firstlist = []

def is_internet_available():
    try:
        # Use a reliable hostname (like Google's DNS) for testing connectivity
        socket.create_connection(("8.8.8.8", 53), timeout=5)
        return True
    except OSError:
        pass
    return False
def get_file_list():
    if not is_internet_available():
        print("No internet connection.")
        return []
    else:
        container_client = blob_service_client.get_container_client(container_name)
        blobs = container_client.list_blobs()
        file_list = [blob.name for blob in blobs]
        return file_list
def get_first_file_list():
    try:
        first_list = []
        first_list = get_file_list()
        return first_list
    except:
        print("Connection Error!!!")
def get_file_from_cloud(previous_files, isNewFWInstall):
    filepath = ""
    isNewSwAvai = "NO"
    # Lấy danh sách tên file hiện tại
    if isNewFWInstall == "YES":
        current_files = get_file_list()
        # Kiểm tra sự thay đổi nếu không phải lần đầu chạy
        added_files = [file for file in current_files if file not in previous_files]
        # In ra thông báo nếu có sự thay đổi
        if added_files:
            print("Đã phát hiện sự thay đổi trong container")
            print("Các file mới được thêm:")
            
            for file in added_files:
                print(file)
                filepath = os.path.join(r'./FOTA_CentralStorage',str(file))
                # Hỏi người dùng có muốn tải xuống file hay không
                user_input = "y"
                if user_input.lower() == 'y':
                    # Tải xuống file
                    container_client = blob_service_client.get_container_client(container_name)
                    blob_client = container_client.get_blob_client(file)
                    with open(os.path.join(r'./FOTA_CentralStorage',str(file)), "wb") as f:
                        f.write(blob_client.download_blob().readall())
                    device_client= IoTHubDeviceClient.create_from_connection_string(CONNECTION_STRING)
                    device_client.connect()
                    isNewSwAvai = "YES"
                    isNewFWInstall = "NO"
                    # device_client.send_message(message)
                    device_client.disconnect()
                # Lưu trữ danh sách tên file hiện tại để so sánh trong lần kiểm tra tiếp theo
            previous_files = current_files 
        else:
            print("Nothing change !!")
    else:
        
        isNewSwAvai = "YES"

    return previous_files, filepath,isNewFWInstall, isNewSwAvai

    
