import sys
import time
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot, QTimer
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QMessageBox, QHBoxLayout

class Worker(QThread):
    # Định nghĩa các tín hiệu và slot của worker
    started = pyqtSignal()
    resultReady = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        # Tạo một biến để lưu thời gian gửi kết quả cuối cùng
        self.lastResultTime = None
        # Khởi tạo biến stop
        self.stop = False

    @pyqtSlot()
    def doWork(self):
        # Thực hiện công việc cần làm cyclic
        while True:
            if not self.stop:
                result = "Hello from worker"
                # Gửi tín hiệu kết quả
                self.resultReady.emit(result)
                # Cập nhật thời gian gửi kết quả cuối cùng
                self.lastResultTime = time.time()
                # Ngủ một giây
                time.sleep(1)
        
    @pyqtSlot()
    def stopWork(self):
        # Đặt biến cờ stop thành True để báo cho thread biết rằng nó cần dừng lại
        self.stop = True

    @pyqtSlot()  
    def restartWork(self):
        # Đặt biến cờ stop thành True để báo cho thread biết rằng nó cần dừng lại
        self.stop = False

class Window(QWidget):
    # Định nghĩa các tín hiệu và slot của window
    operate = pyqtSignal()

    def __init__(self):
        super().__init__()
        # Tạo một đối tượng QThread
        self.thread = QThread()
        # Tạo một đối tượng Worker
        self.worker = Worker()
        # Di chuyển worker vào thread
        self.worker.moveToThread(self.thread)
        # Kết nối các tín hiệu và slot
        self.operate.connect(self.worker.doWork)
        self.worker.resultReady.connect(self.handleResults)

        # Tạo giao diện người dùng

        self.layout = QHBoxLayout()

        self.button = QPushButton("Start", self)
        self.button.clicked.connect(self.startThread)
        self.layout.addWidget(self.button)

        self.stopButton = QPushButton("Stop", self)
        self.stopButton.clicked.connect(self.stopThread)
        self.layout.addWidget(self.stopButton)

        self.restartButton = QPushButton("Restart", self)
        self.restartButton.clicked.connect(self.restartThread)
        self.layout.addWidget(self.restartButton)

        self.setLayout(self.layout)
        self.label = QLabel("Ready", self)

        # Bắt đầu thread
        self.thread.start()

        # Tạo một QTimer để kiểm tra trạng thái của thread
        self.timer = QTimer(self)
        self.timer.setInterval(2000) # Kiểm tra sau mỗi 2 giây
        self.timer.timeout.connect(self.checkThreadStatus)
        self.timer.start()

        
        self.thread_stuck_warning_shown = False  # Thêm biến kiểm soát
    @pyqtSlot()
    def startThread(self):
        # Gửi tín hiệu để bắt đầu xử lý cyclic
        self.operate.emit()

    @pyqtSlot()
    def stopThread(self):
        # Yêu cầu dừng thread
        self.worker.stopWork()
        self.thread_stuck_warning_shown = False

    @pyqtSlot()
    def restartThread(self):
        # Yêu cầu dừng thread hiện tại trước khi restart
        self.worker.restartWork()
        self.thread_stuck_warning_shown = False


    
    @pyqtSlot(str)
    def handleResults(self, result):
        # Xử lý kết quả từ worker
        self.label.setText(result)

    @pyqtSlot()
    def checkThreadStatus(self):
        # Kiểm tra trạng thái của thread
        if self.worker.lastResultTime is not None and not self.thread_stuck_warning_shown:
            # Nếu thời gian gửi kết quả cuối cùng lớn hơn 2 giây, coi như thread bị đứng
            if time.time() - self.worker.lastResultTime > 2:
                
                self.thread_stuck_warning_shown = True

                # Yêu cầu dừng thread
                # Thông báo cho người dùng
                QMessageBox.warning(self, "Warning", "The thread is stuck and has been stopped.")
                

if __name__ == "__main__":
    # Tạo một đối tượng QApplication
    app = QApplication(sys.argv)
    # Tạo một đối tượng Window
    window = Window()
    # Hiển thị window
    window.show()
    # Bắt đầu vòng lặp sự kiện
    sys.exit(app.exec_())
