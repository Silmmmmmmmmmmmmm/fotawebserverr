# Query: FOTA
# ContextLines: 1

124 results - 17 files

dialog.py:
  170          self.label.setText(_translate("Dialog", "Downloading"))
  171:         self.label_2.setText(_translate("Dialog", "FOTA DEMO"))
  172          self.pushButton_4.setText(_translate("Dialog", "Update"))

FOTA_C.py:
  10  from sidebar import Ui_MainWindow
  11: from FOTA_readServerMessages import get_first_file_list
  12: from FOTA_checkPackageServer import get_file_from_cloud
  13: from newSWImageExist import Ui_FOTA_NewFWExist
  14: from FOTA_Installation import install2TECU_Popup
  15  

FOTA_checkPackageServer.py:
   7  # ket noi toi iot hub
   8: CONNECTION_STRING = "HostName=fotadevices.azure-devices.net;DeviceId=fotamaster;SharedAccessKey=RbmlOfiXgz6tuW4IxERLsMmviJYu+AIzVPG6gP0v1qQ="
   9  
  10  # Kết nối tới Azure Storage Account
  11: connection_string = "DefaultEndpointsProtocol=https;AccountName=fotafwstorage2;AccountKey=79xt7Bov9aGr3UxCIO+CJ3nGDNfeZXSkV33E1bxOVgfzz787mMDXrrBS91Nvnd+WaoQSZb5PPVI1+AStRV5jzA==;EndpointSuffix=core.windows.net"
  12  blob_service_client = BlobServiceClient.from_connection_string(connection_string)

  56                  print(file)
  57:                 filepath = os.path.join(r'./FOTA_CentralStorage',str(file))
  58                  # Hỏi người dùng có muốn tải xuống file hay không

  63                      blob_client = container_client.get_blob_client(file)
  64:                     with open(os.path.join(r'./FOTA_CentralStorage',str(file)), "wb") as f:
  65                          f.write(blob_client.download_blob().read())

FOTA_Installation.py:
   6  from PyQt5.QtCore import QTimer, pyqtSignal, pyqtSlot
   7: from FOTA_InstallTECU import  FOTA_TransferFileToAdapter, client_send_and_receive
   8  

  26          if self.isNewFWInstall == "NO":
  27:             FOTA_TransferFileToAdapter(self.filepath)
  28              isFileTransferring = True

FOTA_InstallTECU.py:
  59          file.close()
  60: def FOTA_TransferFileToAdapter(local_file_path):
  61      serverAddress = ('192.168.0.123', 7)

FOTA_readServerMessages.py:
  6  RECEIVED_MESSAGES = 0
  7: CONNECTION_STRING = "HostName=fotadevices.azure-devices.net;SharedAccessKeyName=service;SharedAccessKey=rUYh1yPGbG7duLPE/m1QFxNLii2PP5GvbYhKfOQG6E="
  8  RECEIVED_MESSAGE_DATA = ""

FOTA_UI_Latest.py:
    8  from sidebar import Ui_MainWindow
    9: from FOTA_readServerMessages import *
   10: from FOTA_checkPackageServer import *
   11: from newSWImageExist import Ui_FOTA_NewFWExist
   12: from FOTA_Installation import install2TECU_Popup
   13  import re

   76  
   77: class rb_fota_listenServerReq_thread(QThread):
   78      # Define a signal that will be emitted every 3 seconds

  131      def on_yes_clicked(self):
  132:         rollback_filepath = "".join(['./FOTA_CentralStorage/',self.filepath])
  133          

  157          uic.loadUi(r'newSWImageExist.ui', self)
  158:         self.FOTA_User_Yes.clicked.connect(self.on_yes_clicked)
  159:         self.FOTA_User_No.clicked.connect(self.on_no_clicked)
  160          self.isNewSwInstalled = isNewSwInstalled

  188  
  189:         self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
  190  
  191:         self.rb_fota_listenServerReq_thread.start()
  192  

  254      def loadCentralStorage(self):
  255:         startpath = './FOTA_CentralStorage'
  256          for element in os.listdir(startpath):

  265          self.ui.central_storage.clear() # xóa tất cả các item
  266:         startpath = './FOTA_CentralStorage'
  267          for element in os.listdir(startpath):

FOTA_UI_Updatest.py:
    8  from sidebar import Ui_MainWindow
    9: from FOTA_readServerMessages import *
   10: from FOTA_checkPackageServer import *
   11: from newSWImageExist import Ui_FOTA_NewFWExist
   12: from FOTA_Installation import install2TECU_Popup
   13  import re

   76  
   77: class rb_fota_listenServerReq_thread(QThread):
   78      # Define a signal that will be emitted every 3 seconds

  131      def on_yes_clicked(self):
  132:         rollback_filepath = "".join(['./FOTA_CentralStorage/',self.filepath])
  133          

  157          uic.loadUi(r'newSWImageExist.ui', self)
  158:         self.FOTA_User_Yes.clicked.connect(self.on_yes_clicked)
  159:         self.FOTA_User_No.clicked.connect(self.on_no_clicked)
  160          self.isNewSwInstalled = isNewSwInstalled

  188  
  189:         self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
  190  
  191:         self.rb_fota_listenServerReq_thread.start()
  192  

  254      def loadCentralStorage(self):
  255:         startpath = './FOTA_CentralStorage'
  256          for element in os.listdir(startpath):

  265          self.ui.central_storage.clear() # xóa tất cả các item
  266:         startpath = './FOTA_CentralStorage'
  267          for element in os.listdir(startpath):

FOTA_UI.py:
    7  from sidebar import Ui_MainWindow
    8: from FOTA_readServerMessages import *
    9: from FOTA_checkPackageServer import *
   10: from newSWImageExist import Ui_FOTA_NewFWExist
   11: from FOTA_Installation import install2TECU_Popup
   12  import re

   75  
   76: class rb_fota_listenServerReq_thread(QThread):
   77      # Define a signal that will be emitted every 3 seconds

   99              self.signal.emit()
  100: class rb_fota_checkPackageServer_thread(QThread):
  101      # Define a signal that will be emitted every 3 seconds

  114          uic.loadUi(r'newSWImageExist.ui', self)
  115:         self.FOTA_User_Yes.clicked.connect(self.on_yes_clicked)
  116:         self.FOTA_User_No.clicked.connect(self.on_no_clicked)
  117          self.isNewFWInstall = isNewFWInstall

  151          
  152:         self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
  153:         self.rb_fota_checkPackageServer_thread = rb_fota_checkPackageServer_thread()
  154  
  155          
  156:         self.rb_fota_listenServerReq_thread.signal.connect(self.on_listenServerReq_thread)
  157:         self.rb_fota_checkPackageServer_thread.signal.connect(self.on_checkPakageServer_thread)
  158  
  159          
  160:         self.rb_fota_listenServerReq_thread.start()
  161:         self.rb_fota_checkPackageServer_thread.start()
  162  

install_popup.py:
  191          InstallationPopup.setWindowTitle(_translate("InstallationPopup", "MainWindow"))
  192:         self.header.setText(_translate("InstallationPopup", "FOTA TARGET ECU INSTALLATION STEP"))
  193          self.label_7.setText(_translate("InstallationPopup", "Downloading new software to Target ECU..."))

install_popup.ui:
  47           <property name="text">
  48:           <string>FOTA TARGET ECU INSTALLATION STEP</string>
  49           </property>

installDialog.py:
  196          Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
  197:         self.header.setText(_translate("Dialog", "FOTA TARGET ECU INSTALLATION STEP"))
  198          self.label_7.setText(_translate("Dialog", "Downloading new software to Target ECU..."))

installDialog.ui:
  46          <property name="text">
  47:          <string>FOTA TARGET ECU INSTALLATION STEP</string>
  48          </property>

newSWImageExist.py:
  13  
  14: class Ui_FOTA_NewFWExist(object):
  15:     def setupUi(self, FOTA_NewFWExist):
  16:         FOTA_NewFWExist.setObjectName("FOTA_NewFWExist")
  17:         FOTA_NewFWExist.resize(489, 219)
  18:         self.FOTA_User_Yes = QtWidgets.QPushButton(FOTA_NewFWExist)
  19:         self.FOTA_User_Yes.setGeometry(QtCore.QRect(70, 150, 93, 41))
  20          font = QtGui.QFont()

  23          font.setWeight(75)
  24:         self.FOTA_User_Yes.setFont(font)
  25:         self.FOTA_User_Yes.setObjectName("FOTA_User_Yes")
  26:         self.FOTA_User_No = QtWidgets.QPushButton(FOTA_NewFWExist)
  27:         self.FOTA_User_No.setGeometry(QtCore.QRect(320, 150, 93, 41))
  28          font = QtGui.QFont()

  31          font.setWeight(75)
  32:         self.FOTA_User_No.setFont(font)
  33:         self.FOTA_User_No.setObjectName("FOTA_User_No")
  34:         self.FOTA_NotifyNewFW = QtWidgets.QLabel(FOTA_NewFWExist)
  35:         self.FOTA_NotifyNewFW.setGeometry(QtCore.QRect(50, 60, 381, 31))
  36          font = QtGui.QFont()

  40          font.setWeight(75)
  41:         self.FOTA_NotifyNewFW.setFont(font)
  42:         self.FOTA_NotifyNewFW.setObjectName("FOTA_NotifyNewFW")
  43:         self.FOTA_NotifyNewFW_2 = QtWidgets.QLabel(FOTA_NewFWExist)
  44:         self.FOTA_NotifyNewFW_2.setGeometry(QtCore.QRect(120, 100, 261, 31))
  45          font = QtGui.QFont()

  49          font.setWeight(50)
  50:         self.FOTA_NotifyNewFW_2.setFont(font)
  51:         self.FOTA_NotifyNewFW_2.setObjectName("FOTA_NotifyNewFW_2")
  52:         self.label = QtWidgets.QLabel(FOTA_NewFWExist)
  53          self.label.setGeometry(QtCore.QRect(410, 10, 71, 41))

  59  
  60:         self.retranslateUi(FOTA_NewFWExist)
  61:         QtCore.QMetaObject.connectSlotsByName(FOTA_NewFWExist)
  62  
  63:     def retranslateUi(self, FOTA_NewFWExist):
  64          _translate = QtCore.QCoreApplication.translate
  65:         FOTA_NewFWExist.setWindowTitle(_translate("FOTA_NewFWExist", "Dialog"))
  66:         self.FOTA_User_Yes.setText(_translate("FOTA_NewFWExist", "Yes"))
  67:         self.FOTA_User_No.setText(_translate("FOTA_NewFWExist", "No"))
  68:         self.FOTA_NotifyNewFW.setText(_translate("FOTA_NewFWExist", "New Sw has been downloaded from Server !!!!"))
  69:         self.FOTA_NotifyNewFW_2.setText(_translate("FOTA_NewFWExist", "Do you want to install to TECU ?"))
  70  import main_image_rc

  75      app = QtWidgets.QApplication(sys.argv)
  76:     FOTA_NewFWExist = QtWidgets.QDialog()
  77:     ui = Ui_FOTA_NewFWExist()
  78:     ui.setupUi(FOTA_NewFWExist)
  79:     FOTA_NewFWExist.show()
  80      sys.exit(app.exec_())

newSWImageExist.ui:
   2  <ui version="4.0">
   3:  <class>FOTA_NewFWExist</class>
   4:  <widget class="QDialog" name="FOTA_NewFWExist">
   5    <property name="geometry">

  15    </property>
  16:   <widget class="QPushButton" name="FOTA_User_Yes">
  17     <property name="geometry">

  35    </widget>
  36:   <widget class="QPushButton" name="FOTA_User_No">
  37     <property name="geometry">

  55    </widget>
  56:   <widget class="QLabel" name="FOTA_NotifyNewFW">
  57     <property name="geometry">

  76    </widget>
  77:   <widget class="QLabel" name="FOTA_NotifyNewFW_2">
  78     <property name="geometry">

sidebar.py:
  685          self.central_storage.setObjectName("central_storage")
  686:         self.central_storage.headerItem().setText(0, "FOTA Master - Firmware Central Storage")
  687          self.verticalLayout_23.addWidget(self.central_storage)

  762          MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
  763:         self.logo_label_3.setText(_translate("MainWindow", "FOTA"))
  764          self.home_btn_2.setText(_translate("MainWindow", "Dashboard"))

  819          self.manual_install.setText(_translate("MainWindow", "  Manual Update New SW  "))
  820:         self.groupBox_3.setTitle(_translate("MainWindow", "Download history from FOTA Server to FOTA Master"))
  821:         self.groupBox_4.setTitle(_translate("MainWindow", "List FOTA Server files"))
  822          self.central_storage_gb.setTitle(_translate("MainWindow", "Central Storage folder"))

sidebar.ui:
   280             <property name="text">
   281:             <string>FOTA</string>
   282             </property>

  1489                  <property name="title">
  1490:                  <string>Download history from FOTA Server to FOTA Master</string>
  1491                  </property>

  1535                  <property name="title">
  1536:                  <string>List FOTA Server files</string>
  1537                  </property>

  1587                      <property name="text">
  1588:                      <string notr="true">FOTA Master - Firmware Central Storage</string>
  1589                      </property>
