# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'sidebar.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QGridLayout,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QListWidget, QListWidgetItem, QMainWindow, QPushButton,
    QSizePolicy, QSpacerItem, QStackedWidget, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget)
import main_image_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1177, 591)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.icon_only_widget = QWidget(self.centralwidget)
        self.icon_only_widget.setObjectName(u"icon_only_widget")
        self.verticalLayout_3 = QVBoxLayout(self.icon_only_widget)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.logo_label_1 = QLabel(self.icon_only_widget)
        self.logo_label_1.setObjectName(u"logo_label_1")
        self.logo_label_1.setMinimumSize(QSize(50, 50))
        self.logo_label_1.setMaximumSize(QSize(50, 50))
        self.logo_label_1.setPixmap(QPixmap(u":/icon/icon/Logo.png"))
        self.logo_label_1.setScaledContents(True)

        self.horizontalLayout_3.addWidget(self.logo_label_1)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.home_btn_1 = QPushButton(self.icon_only_widget)
        self.home_btn_1.setObjectName(u"home_btn_1")
        icon = QIcon()
        icon.addFile(u":/icon/icon/home-4-32.ico", QSize(), QIcon.Normal, QIcon.Off)
        icon.addFile(u":/icon/icon/home-4-48.ico", QSize(), QIcon.Normal, QIcon.On)
        self.home_btn_1.setIcon(icon)
        self.home_btn_1.setIconSize(QSize(20, 20))
        self.home_btn_1.setCheckable(True)
        self.home_btn_1.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.home_btn_1)

        self.dashborad_btn_1 = QPushButton(self.icon_only_widget)
        self.dashborad_btn_1.setObjectName(u"dashborad_btn_1")
        icon1 = QIcon()
        icon1.addFile(u":/icon/icon/dashboard-5-32.ico", QSize(), QIcon.Normal, QIcon.Off)
        icon1.addFile(u":/icon/icon/dashboard-5-48.ico", QSize(), QIcon.Normal, QIcon.On)
        self.dashborad_btn_1.setIcon(icon1)
        self.dashborad_btn_1.setIconSize(QSize(20, 20))
        self.dashborad_btn_1.setCheckable(True)
        self.dashborad_btn_1.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.dashborad_btn_1)

        self.orders_btn_1 = QPushButton(self.icon_only_widget)
        self.orders_btn_1.setObjectName(u"orders_btn_1")
        icon2 = QIcon()
        icon2.addFile(u":/icon/icon/activity-feed-32.ico", QSize(), QIcon.Normal, QIcon.Off)
        icon2.addFile(u":/icon/icon/activity-feed-48.ico", QSize(), QIcon.Normal, QIcon.On)
        self.orders_btn_1.setIcon(icon2)
        self.orders_btn_1.setIconSize(QSize(20, 20))
        self.orders_btn_1.setCheckable(True)
        self.orders_btn_1.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.orders_btn_1)

        self.products_btn_1 = QPushButton(self.icon_only_widget)
        self.products_btn_1.setObjectName(u"products_btn_1")
        icon3 = QIcon()
        icon3.addFile(u":/icon/icon/product-32.ico", QSize(), QIcon.Normal, QIcon.Off)
        icon3.addFile(u":/icon/icon/product-48.ico", QSize(), QIcon.Normal, QIcon.On)
        self.products_btn_1.setIcon(icon3)
        self.products_btn_1.setIconSize(QSize(20, 20))
        self.products_btn_1.setCheckable(True)
        self.products_btn_1.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.products_btn_1)


        self.verticalLayout_3.addLayout(self.verticalLayout)

        self.verticalSpacer = QSpacerItem(20, 375, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.exit_btn_1 = QPushButton(self.icon_only_widget)
        self.exit_btn_1.setObjectName(u"exit_btn_1")
        icon4 = QIcon()
        icon4.addFile(u":/icon/icon/close-window-64.ico", QSize(), QIcon.Normal, QIcon.Off)
        self.exit_btn_1.setIcon(icon4)
        self.exit_btn_1.setIconSize(QSize(20, 20))

        self.verticalLayout_3.addWidget(self.exit_btn_1)


        self.gridLayout.addWidget(self.icon_only_widget, 0, 0, 1, 1)

        self.full_menu_widget = QWidget(self.centralwidget)
        self.full_menu_widget.setObjectName(u"full_menu_widget")
        self.verticalLayout_4 = QVBoxLayout(self.full_menu_widget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.logo_label_2 = QLabel(self.full_menu_widget)
        self.logo_label_2.setObjectName(u"logo_label_2")
        self.logo_label_2.setMinimumSize(QSize(40, 40))
        self.logo_label_2.setMaximumSize(QSize(40, 40))
        self.logo_label_2.setPixmap(QPixmap(u":/icon/icon/Logo.png"))
        self.logo_label_2.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.logo_label_2)

        self.logo_label_3 = QLabel(self.full_menu_widget)
        self.logo_label_3.setObjectName(u"logo_label_3")
        font = QFont()
        font.setPointSize(15)
        self.logo_label_3.setFont(font)

        self.horizontalLayout_2.addWidget(self.logo_label_3)


        self.verticalLayout_4.addLayout(self.horizontalLayout_2)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.home_btn_2 = QPushButton(self.full_menu_widget)
        self.home_btn_2.setObjectName(u"home_btn_2")
        self.home_btn_2.setIcon(icon)
        self.home_btn_2.setIconSize(QSize(14, 14))
        self.home_btn_2.setCheckable(True)
        self.home_btn_2.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.home_btn_2)

        self.dashborad_btn_2 = QPushButton(self.full_menu_widget)
        self.dashborad_btn_2.setObjectName(u"dashborad_btn_2")
        self.dashborad_btn_2.setIcon(icon1)
        self.dashborad_btn_2.setIconSize(QSize(14, 14))
        self.dashborad_btn_2.setCheckable(True)
        self.dashborad_btn_2.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.dashborad_btn_2)

        self.orders_btn_2 = QPushButton(self.full_menu_widget)
        self.orders_btn_2.setObjectName(u"orders_btn_2")
        self.orders_btn_2.setIcon(icon2)
        self.orders_btn_2.setIconSize(QSize(14, 14))
        self.orders_btn_2.setCheckable(True)
        self.orders_btn_2.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.orders_btn_2)

        self.products_btn_2 = QPushButton(self.full_menu_widget)
        self.products_btn_2.setObjectName(u"products_btn_2")
        self.products_btn_2.setIcon(icon3)
        self.products_btn_2.setIconSize(QSize(14, 14))
        self.products_btn_2.setCheckable(True)
        self.products_btn_2.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.products_btn_2)


        self.verticalLayout_4.addLayout(self.verticalLayout_2)

        self.verticalSpacer_2 = QSpacerItem(20, 373, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_2)

        self.exit_btn_2 = QPushButton(self.full_menu_widget)
        self.exit_btn_2.setObjectName(u"exit_btn_2")
        self.exit_btn_2.setIcon(icon4)
        self.exit_btn_2.setIconSize(QSize(14, 14))

        self.verticalLayout_4.addWidget(self.exit_btn_2)


        self.gridLayout.addWidget(self.full_menu_widget, 0, 1, 1, 1)

        self.widget_3 = QWidget(self.centralwidget)
        self.widget_3.setObjectName(u"widget_3")
        self.verticalLayout_5 = QVBoxLayout(self.widget_3)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.widget = QWidget(self.widget_3)
        self.widget.setObjectName(u"widget")
        self.widget.setMinimumSize(QSize(0, 40))
        self.horizontalLayout_4 = QHBoxLayout(self.widget)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 9, 0)
        self.change_btn = QPushButton(self.widget)
        self.change_btn.setObjectName(u"change_btn")
        icon5 = QIcon()
        icon5.addFile(u":/icon/icon/menu-4-32.ico", QSize(), QIcon.Normal, QIcon.Off)
        self.change_btn.setIcon(icon5)
        self.change_btn.setIconSize(QSize(14, 14))
        self.change_btn.setCheckable(True)

        self.horizontalLayout_4.addWidget(self.change_btn)

        self.horizontalSpacer = QSpacerItem(236, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName(u"horizontalLayout")

        self.horizontalLayout_4.addLayout(self.horizontalLayout)

        self.label_3 = QLabel(self.widget)
        self.label_3.setObjectName(u"label_3")
        font1 = QFont()
        font1.setPointSize(12)
        font1.setBold(True)
        self.label_3.setFont(font1)

        self.horizontalLayout_4.addWidget(self.label_3)

        self.horizontalSpacer_2 = QSpacerItem(236, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)

        self.label_4 = QLabel(self.widget)
        self.label_4.setObjectName(u"label_4")
        font2 = QFont()
        font2.setItalic(True)
        self.label_4.setFont(font2)

        self.horizontalLayout_4.addWidget(self.label_4)


        self.verticalLayout_5.addWidget(self.widget)

        self.stackedWidget = QStackedWidget(self.widget_3)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.gridLayout_2 = QGridLayout(self.page)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.dashboard = QWidget(self.page)
        self.dashboard.setObjectName(u"dashboard")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.dashboard.sizePolicy().hasHeightForWidth())
        self.dashboard.setSizePolicy(sizePolicy)
        self.horizontalLayout_5 = QHBoxLayout(self.dashboard)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.mainbody = QWidget(self.dashboard)
        self.mainbody.setObjectName(u"mainbody")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.mainbody.sizePolicy().hasHeightForWidth())
        self.mainbody.setSizePolicy(sizePolicy1)
        self.verticalLayout_6 = QVBoxLayout(self.mainbody)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.swInfor = QWidget(self.mainbody)
        self.swInfor.setObjectName(u"swInfor")
        self.horizontalLayout_6 = QHBoxLayout(self.swInfor)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.currSw = QFrame(self.swInfor)
        self.currSw.setObjectName(u"currSw")
        self.currSw.setMaximumSize(QSize(16777215, 60))
        self.currSw.setStyleSheet(u"\n"
"border: 2px solid #9E9E9E;\n"
"border-radius: 15px;\n"
"background-color: #FFFFFF;\n"
"\n"
"")
        self.currSw.setFrameShape(QFrame.StyledPanel)
        self.currSw.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_7 = QHBoxLayout(self.currSw)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.def_currSw = QLabel(self.currSw)
        self.def_currSw.setObjectName(u"def_currSw")
        font3 = QFont()
        font3.setBold(True)
        self.def_currSw.setFont(font3)
        self.def_currSw.setStyleSheet(u"border: 0px solid #9E9E9E;\n"
"\n"
"")
        self.def_currSw.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_7.addWidget(self.def_currSw)

        self.currentSw = QLabel(self.currSw)
        self.currentSw.setObjectName(u"currentSw")
        self.currentSw.setStyleSheet(u"border: 0px;\n"
"color: rgb(255, 0, 0);")
        self.currentSw.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_7.addWidget(self.currentSw)


        self.horizontalLayout_6.addWidget(self.currSw)

        self.lastestSw = QFrame(self.swInfor)
        self.lastestSw.setObjectName(u"lastestSw")
        self.lastestSw.setMaximumSize(QSize(16777215, 60))
        self.lastestSw.setStyleSheet(u"\n"
"border: 2px solid #9E9E9E;\n"
"border-radius: 15px;\n"
"background-color: #FFFFFF;\n"
"")
        self.lastestSw.setFrameShape(QFrame.StyledPanel)
        self.lastestSw.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.lastestSw)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.def_latestSw = QLabel(self.lastestSw)
        self.def_latestSw.setObjectName(u"def_latestSw")
        self.def_latestSw.setFont(font3)
        self.def_latestSw.setStyleSheet(u"border: 0px solid #9E9E9E;\n"
"\n"
"")
        self.def_latestSw.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_8.addWidget(self.def_latestSw)

        self.latestSw = QLabel(self.lastestSw)
        self.latestSw.setObjectName(u"latestSw")
        self.latestSw.setStyleSheet(u"border: 0px;\n"
"color: rgb(0, 255, 0);")
        self.latestSw.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_8.addWidget(self.latestSw)


        self.horizontalLayout_6.addWidget(self.lastestSw)


        self.verticalLayout_6.addWidget(self.swInfor, 0, Qt.AlignTop)

        self.maininfo = QWidget(self.mainbody)
        self.maininfo.setObjectName(u"maininfo")
        sizePolicy.setHeightForWidth(self.maininfo.sizePolicy().hasHeightForWidth())
        self.maininfo.setSizePolicy(sizePolicy)
        self.horizontalLayout_10 = QHBoxLayout(self.maininfo)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.mainfr = QFrame(self.maininfo)
        self.mainfr.setObjectName(u"mainfr")
        self.mainfr.setFrameShape(QFrame.StyledPanel)
        self.mainfr.setFrameShadow(QFrame.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.mainfr)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.main_image = QLabel(self.mainfr)
        self.main_image.setObjectName(u"main_image")
        self.main_image.setStyleSheet(u"image: url(:/image/model_pic.png);")
        self.main_image.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.main_image)


        self.horizontalLayout_10.addWidget(self.mainfr)


        self.verticalLayout_6.addWidget(self.maininfo)


        self.horizontalLayout_5.addWidget(self.mainbody)

        self.Sw_log = QWidget(self.dashboard)
        self.Sw_log.setObjectName(u"Sw_log")
        self.verticalLayout_24 = QVBoxLayout(self.Sw_log)
        self.verticalLayout_24.setSpacing(0)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.verticalLayout_24.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.Sw_log)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.pushButton = QPushButton(self.frame)
        self.pushButton.setObjectName(u"pushButton")

        self.horizontalLayout_9.addWidget(self.pushButton)

        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")

        self.horizontalLayout_9.addWidget(self.label)


        self.verticalLayout_24.addWidget(self.frame)

        self.listSwLog = QListWidget(self.Sw_log)
        self.listSwLog.setObjectName(u"listSwLog")
        self.listSwLog.setMaximumSize(QSize(250, 16777215))

        self.verticalLayout_24.addWidget(self.listSwLog)


        self.horizontalLayout_5.addWidget(self.Sw_log, 0, Qt.AlignRight)


        self.gridLayout_2.addWidget(self.dashboard, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.page)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.verticalLayout_10 = QVBoxLayout(self.page_2)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.widget_4 = QWidget(self.page_2)
        self.widget_4.setObjectName(u"widget_4")
        self.verticalLayout_11 = QVBoxLayout(self.widget_4)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.groupBox = QGroupBox(self.widget_4)
        self.groupBox.setObjectName(u"groupBox")
        font4 = QFont()
        font4.setPointSize(10)
        font4.setBold(True)
        self.groupBox.setFont(font4)
        self.horizontalLayout_15 = QHBoxLayout(self.groupBox)
        self.horizontalLayout_15.setSpacing(0)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(0, 0, 0, 0)
        self.widget_5 = QWidget(self.groupBox)
        self.widget_5.setObjectName(u"widget_5")
        sizePolicy1.setHeightForWidth(self.widget_5.sizePolicy().hasHeightForWidth())
        self.widget_5.setSizePolicy(sizePolicy1)
        self.verticalLayout_14 = QVBoxLayout(self.widget_5)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.DiagServices = QComboBox(self.widget_5)
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.addItem("")
        self.DiagServices.setObjectName(u"DiagServices")
        font5 = QFont()
        font5.setPointSize(10)
        font5.setBold(False)
        self.DiagServices.setFont(font5)

        self.verticalLayout_14.addWidget(self.DiagServices)


        self.horizontalLayout_15.addWidget(self.widget_5)

        self.widget_6 = QWidget(self.groupBox)
        self.widget_6.setObjectName(u"widget_6")
        self.verticalLayout_13 = QVBoxLayout(self.widget_6)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.sendDiag = QPushButton(self.widget_6)
        self.sendDiag.setObjectName(u"sendDiag")
        self.sendDiag.setMaximumSize(QSize(80, 80))

        self.verticalLayout_13.addWidget(self.sendDiag)


        self.horizontalLayout_15.addWidget(self.widget_6, 0, Qt.AlignRight)


        self.verticalLayout_11.addWidget(self.groupBox)


        self.verticalLayout_10.addWidget(self.widget_4)

        self.widget_2 = QWidget(self.page_2)
        self.widget_2.setObjectName(u"widget_2")
        self.verticalLayout_12 = QVBoxLayout(self.widget_2)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.groupBox_2 = QGroupBox(self.widget_2)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.groupBox_2.setFont(font4)
        self.verticalLayout_15 = QVBoxLayout(self.groupBox_2)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(11, -1, -1, -1)
        self.DiagResponse = QListWidget(self.groupBox_2)
        self.DiagResponse.setObjectName(u"DiagResponse")

        self.verticalLayout_15.addWidget(self.DiagResponse)

        self.ClearWindow_Btn = QPushButton(self.groupBox_2)
        self.ClearWindow_Btn.setObjectName(u"ClearWindow_Btn")

        self.verticalLayout_15.addWidget(self.ClearWindow_Btn)


        self.verticalLayout_12.addWidget(self.groupBox_2)


        self.verticalLayout_10.addWidget(self.widget_2)

        self.stackedWidget.addWidget(self.page_2)
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.verticalLayout_16 = QVBoxLayout(self.page_3)
        self.verticalLayout_16.setSpacing(3)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(-1, -1, 11, -1)
        self.widget_8 = QWidget(self.page_3)
        self.widget_8.setObjectName(u"widget_8")
        self.widget_8.setMinimumSize(QSize(300, 0))
        self.widget_8.setMaximumSize(QSize(16777215, 200))
        self.horizontalLayout_11 = QHBoxLayout(self.widget_8)
        self.horizontalLayout_11.setSpacing(0)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 20, 0)
        self.label_2 = QLabel(self.widget_8)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.label_2)

        self.manual_install = QPushButton(self.widget_8)
        self.manual_install.setObjectName(u"manual_install")
        self.manual_install.setMaximumSize(QSize(100, 80))

        self.horizontalLayout_11.addWidget(self.manual_install)


        self.verticalLayout_16.addWidget(self.widget_8, 0, Qt.AlignRight|Qt.AlignTop)

        self.widget_9 = QWidget(self.page_3)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy2)
        self.verticalLayout_18 = QVBoxLayout(self.widget_9)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(0, 0, 0, 0)
        self.groupBox_3 = QGroupBox(self.widget_9)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setFont(font4)
        self.verticalLayout_20 = QVBoxLayout(self.groupBox_3)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.downloadCloud_log = QListWidget(self.groupBox_3)
        self.downloadCloud_log.setObjectName(u"downloadCloud_log")
        sizePolicy1.setHeightForWidth(self.downloadCloud_log.sizePolicy().hasHeightForWidth())
        self.downloadCloud_log.setSizePolicy(sizePolicy1)

        self.verticalLayout_20.addWidget(self.downloadCloud_log)


        self.verticalLayout_18.addWidget(self.groupBox_3)


        self.verticalLayout_16.addWidget(self.widget_9)

        self.widget_7 = QWidget(self.page_3)
        self.widget_7.setObjectName(u"widget_7")
        self.verticalLayout_19 = QVBoxLayout(self.widget_7)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.groupBox_4 = QGroupBox(self.widget_7)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.groupBox_4.setFont(font3)
        self.verticalLayout_21 = QVBoxLayout(self.groupBox_4)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.listServerfile = QListWidget(self.groupBox_4)
        self.listServerfile.setObjectName(u"listServerfile")

        self.verticalLayout_21.addWidget(self.listServerfile)


        self.verticalLayout_19.addWidget(self.groupBox_4)


        self.verticalLayout_16.addWidget(self.widget_7)

        self.stackedWidget.addWidget(self.page_3)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.gridLayout_5 = QGridLayout(self.page_4)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.mainCloud = QWidget(self.page_4)
        self.mainCloud.setObjectName(u"mainCloud")
        self.verticalLayout_22 = QVBoxLayout(self.mainCloud)
        self.verticalLayout_22.setSpacing(0)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setContentsMargins(0, 0, 0, 0)
        self.central_storage_gb = QGroupBox(self.mainCloud)
        self.central_storage_gb.setObjectName(u"central_storage_gb")
        self.verticalLayout_23 = QVBoxLayout(self.central_storage_gb)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.central_storage = QTreeWidget(self.central_storage_gb)
        __qtreewidgetitem = QTreeWidgetItem()
        __qtreewidgetitem.setText(0, u"FOTA Master - Firmware Central Storage");
        self.central_storage.setHeaderItem(__qtreewidgetitem)
        self.central_storage.setObjectName(u"central_storage")
        font6 = QFont()
        font6.setPointSize(12)
        font6.setBold(False)
        font6.setItalic(False)
        self.central_storage.setFont(font6)

        self.verticalLayout_23.addWidget(self.central_storage)


        self.verticalLayout_22.addWidget(self.central_storage_gb)


        self.gridLayout_5.addWidget(self.mainCloud, 0, 0, 1, 1)

        self.widget_11 = QWidget(self.page_4)
        self.widget_11.setObjectName(u"widget_11")
        self.horizontalLayout_16 = QHBoxLayout(self.widget_11)
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.pushButton_3 = QPushButton(self.widget_11)
        self.pushButton_3.setObjectName(u"pushButton_3")

        self.horizontalLayout_16.addWidget(self.pushButton_3)

        self.pushButton_4 = QPushButton(self.widget_11)
        self.pushButton_4.setObjectName(u"pushButton_4")

        self.horizontalLayout_16.addWidget(self.pushButton_4)


        self.gridLayout_5.addWidget(self.widget_11, 1, 0, 1, 1)

        self.stackedWidget.addWidget(self.page_4)

        self.verticalLayout_5.addWidget(self.stackedWidget)


        self.gridLayout.addWidget(self.widget_3, 0, 2, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.change_btn.toggled.connect(self.icon_only_widget.setVisible)
        self.change_btn.toggled.connect(self.full_menu_widget.setHidden)
        self.home_btn_1.toggled.connect(self.home_btn_2.setChecked)
        self.dashborad_btn_1.toggled.connect(self.dashborad_btn_2.setChecked)
        self.orders_btn_1.toggled.connect(self.orders_btn_2.setChecked)
        self.products_btn_1.toggled.connect(self.products_btn_2.setChecked)
        self.home_btn_2.toggled.connect(self.home_btn_1.setChecked)
        self.dashborad_btn_2.toggled.connect(self.dashborad_btn_1.setChecked)
        self.orders_btn_2.toggled.connect(self.orders_btn_1.setChecked)
        self.products_btn_2.toggled.connect(self.products_btn_1.setChecked)
        self.exit_btn_2.clicked.connect(MainWindow.close)
        self.exit_btn_1.clicked.connect(MainWindow.close)

        self.stackedWidget.setCurrentIndex(3)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.logo_label_1.setText("")
        self.home_btn_1.setText("")
        self.dashborad_btn_1.setText("")
        self.orders_btn_1.setText("")
        self.products_btn_1.setText("")
        self.exit_btn_1.setText("")
        self.logo_label_2.setText("")
        self.logo_label_3.setText(QCoreApplication.translate("MainWindow", u"FOTA", None))
        self.home_btn_2.setText(QCoreApplication.translate("MainWindow", u"Dashboard", None))
        self.dashborad_btn_2.setText(QCoreApplication.translate("MainWindow", u"Diagnostic Test", None))
        self.orders_btn_2.setText(QCoreApplication.translate("MainWindow", u"Cloud", None))
        self.products_btn_2.setText(QCoreApplication.translate("MainWindow", u"Central Storage", None))
        self.exit_btn_2.setText(QCoreApplication.translate("MainWindow", u"Exit", None))
        self.change_btn.setText("")
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Telematic Gateway", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"FOTA Program", None))
        self.def_currSw.setText(QCoreApplication.translate("MainWindow", u"Current ECU SW Version:", None))
        self.currentSw.setText(QCoreApplication.translate("MainWindow", u"SwVersion", None))
        self.def_latestSw.setText(QCoreApplication.translate("MainWindow", u"Latest ECU SW Version:", None))
        self.latestSw.setText(QCoreApplication.translate("MainWindow", u"LatestSWVersion", None))
        self.main_image.setText("")
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Check Internet Connection", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Connected", None))
        self.groupBox.setTitle(QCoreApplication.translate("MainWindow", u"Diagnostic Service Request", None))
        self.DiagServices.setItemText(0, QCoreApplication.translate("MainWindow", u"10 01 Default Session Start", None))
        self.DiagServices.setItemText(1, QCoreApplication.translate("MainWindow", u"10 02 Programming Session Start", None))
        self.DiagServices.setItemText(2, QCoreApplication.translate("MainWindow", u"10 03 Extended Session Start", None))
        self.DiagServices.setItemText(3, QCoreApplication.translate("MainWindow", u"22 10 04 General Information Read", None))
        self.DiagServices.setItemText(4, QCoreApplication.translate("MainWindow", u"22 10 01 CGW Data2 Read", None))
        self.DiagServices.setItemText(5, QCoreApplication.translate("MainWindow", u"22 10 00 CGW Data Read", None))
        self.DiagServices.setItemText(6, QCoreApplication.translate("MainWindow", u"22 F1 99 Programming Date Read", None))
        self.DiagServices.setItemText(7, QCoreApplication.translate("MainWindow", u"22 F1 98 Repair Shop Code Read", None))
        self.DiagServices.setItemText(8, QCoreApplication.translate("MainWindow", u"22 F1 95 System supplier ECU software version Read", None))
        self.DiagServices.setItemText(9, QCoreApplication.translate("MainWindow", u"22 F1 91 ECU Hardware Part Number Read", None))
        self.DiagServices.setItemText(10, QCoreApplication.translate("MainWindow", u"22 F1 90 VIN Read", None))
        self.DiagServices.setItemText(11, QCoreApplication.translate("MainWindow", u"22 F1 01 Component ID Read", None))
        self.DiagServices.setItemText(12, QCoreApplication.translate("MainWindow", u"22 F1 8C ECU Serial Number Read", None))
        self.DiagServices.setItemText(13, QCoreApplication.translate("MainWindow", u"22 F1 89 ECU Software Version Read", None))
        self.DiagServices.setItemText(14, QCoreApplication.translate("MainWindow", u"22 F1 88 ECU Software Number Read", None))
        self.DiagServices.setItemText(15, QCoreApplication.translate("MainWindow", u"22 F1 86 Active Diagnostic Session Read", None))
        self.DiagServices.setItemText(16, QCoreApplication.translate("MainWindow", u"22 10 02 CGW Data3 Read", None))
        self.DiagServices.setItemText(17, QCoreApplication.translate("MainWindow", u"22 10 05 Mode_Transition_Status Read", None))
        self.DiagServices.setItemText(18, QCoreApplication.translate("MainWindow", u"22 10 10 Security Type for Ext Session Read", None))
        self.DiagServices.setItemText(19, QCoreApplication.translate("MainWindow", u"22 10 12 Security Type for Programming Session Read", None))
        self.DiagServices.setItemText(20, QCoreApplication.translate("MainWindow", u"22 1F 00 Freeze Frame Data Read", None))
        self.DiagServices.setItemText(21, QCoreApplication.translate("MainWindow", u"22 60 00 Access Log 1 Read", None))
        self.DiagServices.setItemText(22, QCoreApplication.translate("MainWindow", u"22 60 01 Access Log 2 Read", None))
        self.DiagServices.setItemText(23, QCoreApplication.translate("MainWindow", u"22 60 03 Access Log 4 Read", None))
        self.DiagServices.setItemText(24, QCoreApplication.translate("MainWindow", u"22 10 03 SDR Information Read", None))
        self.DiagServices.setItemText(25, QCoreApplication.translate("MainWindow", u"22 60 03 Access Log 3 Read", None))
        self.DiagServices.setItemText(26, QCoreApplication.translate("MainWindow", u"22 60 04 Access Log 5 Read", None))
        self.DiagServices.setItemText(27, QCoreApplication.translate("MainWindow", u"22 60 05 Access Log 6 Read", None))
        self.DiagServices.setItemText(28, QCoreApplication.translate("MainWindow", u"22 60 06 Access Log 7 Read", None))

        self.DiagServices.setCurrentText(QCoreApplication.translate("MainWindow", u"10 01 Default Session Start", None))
        self.sendDiag.setText(QCoreApplication.translate("MainWindow", u"Send", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("MainWindow", u"Diagnostic Service Response", None))
        self.ClearWindow_Btn.setText(QCoreApplication.translate("MainWindow", u"Clear window", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"NewSwStatus", None))
        self.manual_install.setText(QCoreApplication.translate("MainWindow", u"Manual Update", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("MainWindow", u"Download history from FOTA Server to FOTA Master", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("MainWindow", u"List FOTA Server files", None))
        self.central_storage_gb.setTitle(QCoreApplication.translate("MainWindow", u"Central Storage folder", None))
        self.pushButton_3.setText(QCoreApplication.translate("MainWindow", u"Refresh", None))
        self.pushButton_4.setText(QCoreApplication.translate("MainWindow", u"External Rollback for TECU", None))
    # retranslateUi

