import sys
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QDialog, QListWidgetItem,QMessageBox,QLineEdit, QTreeWidgetItem
from PyQt5.QtCore import pyqtSlot, QFile, QTextStream, QThread, pyqtSignal
from PyQt5 import uic, QtWidgets
from PyQt5.QtGui import QIcon
import time, os
from sidebar import Ui_MainWindow
from install_popup import Ui_InstallationPopup
from datetime import datetime

loadCentralStorage = False

class rb_fota_listenServerReq_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
           
            time.sleep(1)
            self.signal.emit()
class rb_fota_checkPackageServer_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
            time.sleep(2)
            self.signal.emit()
class rb_fota_sendServerRes_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
            time.sleep(3)
            self.signal.emit()
class InstallPopup(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi(r'installDialog.ui', self)
        self.confirmBtn.clicked.connect(self.on_confirm_clicked)


    def on_confirm_clicked(self):
        print("o day thi sao")
        # Add your code here for when the "Yes" button is clicked
        # dialog = ProgressDialog(downloadFilePath, self.isNewFWInstall)
        # dialog.valueUpdated.connect(self.handle_new_fw_install)
        
        # dialog.exec_()
        print("Yes button clicked")
        self.accept()  # Close the dialog
        
class UserConfirmationPopup(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi(r'newSWImageExist.ui', self)
        self.FOTA_User_Yes.clicked.connect(self.on_yes_clicked)
        self.FOTA_User_No.clicked.connect(self.on_no_clicked)

    def on_yes_clicked(self):
        print("o day thi sao")
        # Add your code here for when the "Yes" button is clicked
        # dialog = ProgressDialog(downloadFilePath, self.isNewFWInstall)
        # dialog.valueUpdated.connect(self.handle_new_fw_install)
        
        # dialog.exec_()
        print("Yes button clicked")
        install_Popup = InstallPopup()
        install_Popup.exec_()
        self.accept()  # Close the dialog
    def handle_new_fw_install(self, value):
        if value == "YES":
            global isNewFWInstall
            global userConfirm
            isNewFWInstall = "YES"
            userConfirm = False
            print("userConfirm: ",userConfirm)
            print("WHAT THE HELLL??????????????????? ",isNewFWInstall)
            
    def on_no_clicked(self):
        # Add your code here for when the "No" button is clicked
        print("No button clicked")
        self.reject()  # Close the dialog
        

            
                    
class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        # Load and populate data from the text file
        
        
        self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
        self.rb_fota_checkPackageServer_thread = rb_fota_checkPackageServer_thread()
        self.rb_fota_sendServerRes_thread = rb_fota_sendServerRes_thread()
        
        self.rb_fota_listenServerReq_thread.signal.connect(self.loadCS_one)

        
        self.rb_fota_listenServerReq_thread.start()
 
        
        self.ui.icon_only_widget.hide()
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.home_btn_2.setChecked(True)
        
        self.ui.pushButton_3.clicked.connect(self.reloadCentralStorage)
        
        # self.ui.DiagServices.addItem("DiagInformation")
        # self.ui.DiagServices.addItem("Diag SoftwareVersion")
        # self.ui.sendDiag.clicked.connect(self.select_copyText)
        
        self.ui.sendDiag.clicked.connect(self.addDiagResponse)
        
        self.ui.pushButton.clicked.connect(self.addSwListLog)
        self.ui.pushButton_4.clicked.connect(self.getCurrentFilePath)
        
    def loadCS_one(self):
        global loadCentralStorage
        if loadCentralStorage == False:
            self.loadCentralStorage()
            loadCentralStorage = True
            
    def addDiagResponse(self):
        text = "This is new"
        icon_done = QIcon("done.png")
        icon_error = QIcon("error.png")
        new_item = QListWidgetItem(icon_done, text)
        self.ui.DiagResponse.addItem(new_item)
    def addSwListLog(self):
        now = datetime.now()
        formatted = now.strftime("%d/%m/%Y %H:%M:%S")
        information = "This is newwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"
        text = "{} - {}".format(information, formatted)
        icon_done = QIcon("done.png")
        icon_error = QIcon("error.png")
        new_item = QListWidgetItem(icon_done, text)
        self.ui.listSwLog.addItem(new_item)
        
    def loadCentralStorage(self):
        startpath = 'C:\Silm\EAE31-TOPIC\FOTA\FOTA_Master\PyQt5-Video-Book-main\Base_Ui_FOTAMASTER\Official_UiApp\icon'
        for element in os.listdir(startpath):
            path_info = startpath + "/" + element
            parent_itm = QTreeWidgetItem(self.ui.central_storage, [os.path.basename(element)])
            if os.path.isdir(path_info):
                parent_itm.setIcon(0, QIcon('folder.png'))
            else:
                parent_itm.setIcon(0, QIcon('file.png'))
                
    def reloadCentralStorage(self):
        self.ui.central_storage.clear() # xóa tất cả các item
        startpath = 'C:\Silm\EAE31-TOPIC\FOTA\FOTA_Master\PyQt5-Video-Book-main\Base_Ui_FOTAMASTER\Official_UiApp\icon'
        for element in os.listdir(startpath):
            path_info = startpath + "/" + element
            parent_itm = QTreeWidgetItem(self.ui.central_storage, [os.path.basename(element)])
            if os.path.isdir(path_info):
                # load_project_structure(path_info, parent_itm)
                parent_itm.setIcon(0, QIcon('folder.png'))
            else:
                parent_itm.setIcon(0, QIcon('file.png'))
        # self.ui.central_storage.addTopLevelItems(items)
        
    def getCurrentFilePath(self):
        curr_file = self.ui.central_storage.currentItem()
        if curr_file:
            # Lấy giá trị của phần tử
            filepath = curr_file.text(0)
            QMessageBox.information(self,'Copy',f'Filepath: {filepath} ')
        
        
    def loadListServerFile(self):
        listServerFile =['file1.bin', 'file1.bin','file1.bin','file1.bin','file1.bin','file1.bin','file1.bin','file1.bin']
        for value in listServerFile:
            file_icon = QIcon("file.png")
            new_item = QListWidgetItem(file_icon, value)
            self.ui.listServerfile.addItem(new_item)

     #Select function 
    
    def select_copyText(self):
        seleccopytext= self.ui.DiagServices.currentText()
        clipboard_1= QApplication.clipboard()
        clipboard_1.setText(seleccopytext)
        QMessageBox.information(self,'Copy',f'Send Message: {seleccopytext} to system')
    # Def add item to ListWidget
    def addItemToList(self):
        #text input for update
        text = self.lineEdit.text()
        if text:
            new_item = QListWidgetItem(text)
            self.listWidget.addItem(new_item)
            
            
    # def load_data_from_text_file(self, file_path):
    #     try:
    #         with open(file_path, 'r') as file:
    #             for line in file:
    #                 line = line.strip()
    #                 if line:
    #                     item = QListWidgetItem(line)
    #                     self.ui.listSwLog.addItem(item)
    #     except FileNotFoundError:
    #         print(f"File '{file_path}' not found.")
    @pyqtSlot()
    def on_listenServerReq_thread(self):
        print("Signal received from cyclic thread1!")

    ## Function for searching
    def on_search_btn_clicked(self):
        self.ui.stackedWidget.setCurrentIndex(5)
        search_text = self.ui.search_input.text().strip()
        if search_text:
            self.ui.label_9.setText(search_text)

    ## Function for changing page to user page
    def on_user_btn_clicked(self):
        dialog = UserConfirmationPopup()
        dialog.exec_()
        self.ui.stackedWidget.setCurrentIndex(6)

    ## Change QPushButton Checkable status when stackedWidget index changed
    def on_stackedWidget_currentChanged(self, index):
        btn_list = self.ui.icon_only_widget.findChildren(QPushButton) \
                    + self.ui.full_menu_widget.findChildren(QPushButton)
        
        for btn in btn_list:
            if index in [5, 6]:
                btn.setAutoExclusive(False)
                btn.setChecked(False)
            else:
                btn.setAutoExclusive(True)
            
    ## functions for changing menu page
    def on_home_btn_1_toggled(self):
        self.loadListServerFile()
        self.ui.stackedWidget.setCurrentIndex(0)
    
    def on_home_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(0)

    def on_dashborad_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_dashborad_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_orders_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_orders_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_products_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_products_btn_2_toggled(self ):
        
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_customers_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)

    def on_customers_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    ## loading style file
    # with open("style.qss", "r") as style_file:
    #     style_str = style_file.read()
    # app.setStyleSheet(style_str)

    ## loading style file, Example 2
    style_file = QFile("style.qss")
    style_file.open(QFile.ReadOnly | QFile.Text)
    style_stream = QTextStream(style_file)
    app.setStyleSheet(style_stream.readAll())


    window = MainWindow()
    window.show()

    sys.exit(app.exec())



