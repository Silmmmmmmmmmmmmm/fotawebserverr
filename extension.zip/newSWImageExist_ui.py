# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'newSWImageExist.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QLabel, QPushButton,
    QSizePolicy, QWidget)
import main_image_rc

class Ui_FOTA_NewFWExist(object):
    def setupUi(self, FOTA_NewFWExist):
        if not FOTA_NewFWExist.objectName():
            FOTA_NewFWExist.setObjectName(u"FOTA_NewFWExist")
        FOTA_NewFWExist.resize(489, 219)
        self.FOTA_User_Yes = QPushButton(FOTA_NewFWExist)
        self.FOTA_User_Yes.setObjectName(u"FOTA_User_Yes")
        self.FOTA_User_Yes.setGeometry(QRect(70, 150, 93, 41))
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        self.FOTA_User_Yes.setFont(font)
        self.FOTA_User_No = QPushButton(FOTA_NewFWExist)
        self.FOTA_User_No.setObjectName(u"FOTA_User_No")
        self.FOTA_User_No.setGeometry(QRect(320, 150, 93, 41))
        font1 = QFont()
        font1.setPointSize(14)
        font1.setBold(True)
        self.FOTA_User_No.setFont(font1)
        self.FOTA_NotifyNewFW = QLabel(FOTA_NewFWExist)
        self.FOTA_NotifyNewFW.setObjectName(u"FOTA_NotifyNewFW")
        self.FOTA_NotifyNewFW.setGeometry(QRect(50, 60, 381, 31))
        font2 = QFont()
        font2.setFamilies([u"Myanmar Text"])
        font2.setPointSize(10)
        font2.setBold(True)
        self.FOTA_NotifyNewFW.setFont(font2)
        self.FOTA_NotifyNewFW_2 = QLabel(FOTA_NewFWExist)
        self.FOTA_NotifyNewFW_2.setObjectName(u"FOTA_NotifyNewFW_2")
        self.FOTA_NotifyNewFW_2.setGeometry(QRect(120, 100, 261, 31))
        font3 = QFont()
        font3.setFamilies([u"Myanmar Text"])
        font3.setPointSize(10)
        font3.setBold(False)
        self.FOTA_NotifyNewFW_2.setFont(font3)
        self.label = QLabel(FOTA_NewFWExist)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(410, 10, 71, 41))
        self.label.setMaximumSize(QSize(231, 81))
        self.label.setStyleSheet(u"\n"
"image: url(:/image/icon/bosch.webp);")

        self.retranslateUi(FOTA_NewFWExist)

        QMetaObject.connectSlotsByName(FOTA_NewFWExist)
    # setupUi

    def retranslateUi(self, FOTA_NewFWExist):
        FOTA_NewFWExist.setWindowTitle(QCoreApplication.translate("FOTA_NewFWExist", u"Dialog", None))
        self.FOTA_User_Yes.setText(QCoreApplication.translate("FOTA_NewFWExist", u"Yes", None))
        self.FOTA_User_No.setText(QCoreApplication.translate("FOTA_NewFWExist", u"No", None))
        self.FOTA_NotifyNewFW.setText(QCoreApplication.translate("FOTA_NewFWExist", u"New Sw has been downloaded from Server !!!!", None))
        self.FOTA_NotifyNewFW_2.setText(QCoreApplication.translate("FOTA_NewFWExist", u"Do you want to install to TECU ?", None))
        self.label.setText("")
    # retranslateUi

