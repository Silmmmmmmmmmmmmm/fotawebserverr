import sys
from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QProgressBar, QVBoxLayout, QLabel, QMainWindow, QFileDialog, QFormLayout, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5 import uic
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer, pyqtSignal, pyqtSlot
from FOTA_InstallTECU import  FOTA_TransferFileToAdapter, client_send_and_receive

class install2TECU_Popup(QDialog):
    valueUpdated = pyqtSignal(str)
    def __init__(self, filepath, isNewFWInstall):
        super().__init__()
        uic.loadUi(r'installDialog.ui', self)
        self.progressBar_2.setValue(0)
        self.confirmBtn.setEnabled(False)
        self.confirmBtn.clicked.connect(self.close)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_progress)
        self.timer.start(100)
        
        self.filepath = filepath
        self.isNewFWInstall = isNewFWInstall
    def update_progress(self):
        serverAddress = ('192.168.0.123', 7)       
        if self.isNewFWInstall == "NO":
            FOTA_TransferFileToAdapter(self.filepath)
            isFileTransferring = True
            complete_flag = False
            while isFileTransferring:
                msg = "REQ_SEQ_STATUS"
                if msg != '':  # Validate the message
                    response = client_send_and_receive(serverAddress, msg)  # Send the command to the server and receive the response
                    msg = ''  
                    if response is not None:
                        print('Data received:', response)
                        if response == "RESP_EXT_SESS_SUCCESS":
                            current_value = "RESP_EXT_SESS_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(15)
                        elif response == "RESP_SEC_ACCESS_B_SUCCESS" :
                            current_value = "RESP_SEC_ACCESS_B_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(20)
                        elif response == "RESP_SET_PROGMD_SUCCESS" :
                            current_value = "RESP_SET_PROGMD_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(22)
                        elif response == "RESP_PROG_SESS_SUCCESS" :
                            current_value = "RESP_PROG_SESS_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(25)
                        elif response == "RESP_SEC_ACCESS_A_SUCCESS" :
                            current_value = "RESP_SEC_ACCESS_A_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(30)
                        elif response == "RESP_IDWRITE_REPAIR_SUCCESS" :
                            current_value = "RESP_IDWRITE_REPAIR_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(32)
                        elif response == "RESP_IDWRITE_PROG_SUCCESS" :
                            current_value = "RESP_IDWRITE_PROG_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(35)
                        elif response == "RESP_ERASE_APP_SUCCESS" :
                            current_value = "RESP_ERASE_APP_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(40)
                        elif response == "RESP_TESTER_PRESENT_SUCCESS" :
                            current_value = "RESP_TESTER_PRESENT_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(41)
                        elif response == "RESP_REQ_TRANSFER_SUCCESS" :
                            complete_flag = True
                            current_value = "RESP_REQ_TRANSFER_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(42)
                        elif response[0:25] == "RESP_TRANSFER_APP_SUCCESS":
                            current_memfill = (int(response[26:29])/ 224) * 100
                            current_value_mem = str(int(current_memfill))
                            self.progressBar_memfill.setValue(current_memfill)
                            self.memfillPercent.setText(f"{current_value_mem} %")
                            current_value = "RESP_TRANSFERRING_APP"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(55)
                        elif response == "RESP_EXIT_TRANSFER_SUCCESS" :
                            current_value = "RESP_EXIT_TRANSFER_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(90)
                        elif response == "RESP_READ_DTC_SUCCESS" :
                            current_value = "RESP_READ_DTC_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(95)
                        elif response == "RESP_RID_CHECK_SUCCESS" :
                            current_value = "RESP_RID_CHECK_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(97)
                        elif complete_flag == True and response == "RESP_DEFAULT_SESSION":
                            current_value = "RESP_ECU_RESET_SUCCESS"
                            self.curr_step.setText(f"{current_value}")
                            self.progressBar_2.setValue(100)
                            self.isNewFWInstall = "YES"
                            self.valueUpdated.emit(self.isNewFWInstall)
                            isFileTransferring = False
                            complete_flag = False
                        
                        else:
#                             QMessageBox.information(self,'RESPONSE WINDOW',f'Error when reprogramming!!!')
                            print('Invalid or empty message.')
                            
            response_new = client_send_and_receive(serverAddress, "DEFAULT_SS")
            current_value = "COMPLETED"
            self.curr_step.setText(f"{current_value}")
            self.confirmBtn.setEnabled(True)
        else:
            current_value = "NO NEW SW AVAILABLE"
            self.curr_step.setText(f"{current_value}")
            self.confirmBtn.setEnabled(True)
        
        
  
        self.timer.stop()
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    dialog = install2TECU_Popup()
    dialog.exec_()
