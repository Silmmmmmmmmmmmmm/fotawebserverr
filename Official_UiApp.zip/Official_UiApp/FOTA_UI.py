import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QDialog, QListWidgetItem
from PyQt5.QtCore import pyqtSlot, QFile, QTextStream, QThread, pyqtSignal, QTimer
import time 
from sidebar import Ui_MainWindow
from FOTA_readServerMessages import *
from FOTA_checkPackageServer import *
from newSWImageExist import Ui_FOTA_NewFWExist
from FOTA_Installation import install2TECU_Popup
import re

# Server Message Flag - False: No message - True: New Server Message is available
isNewServerMsg = False
# Base Server File List - List of files in Server - Azure Blob Storage
baseServerFileList = []
# New Software available flag
isNewSwAvai = "NO"
# Installation status of new Sw
isNewFWInstall = "YES"
# Download file path - New Sw file will be downloaded into Central Storage folder
downloadFilePath = ""
# TFTP file transfer flag
isFileTransferred = "NO"
# User confirmation on Popupwindow
userConfirm = False

# Sends a message to the server and receives the response over TCP.
def client_send_and_receive(server_address, message):
    global isNewServerMsg
    bufferSize = 1024
    timeout = 5  # Set a timeout value of 5 seconds
    TCPClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Create a TCP socket
    TCPClient.settimeout(timeout)  # Set socket timeout
    TCPClient.connect(server_address)
    print('Connect successfully. Server IP address: {0}. Port: {1}'.format(server_address[0], server_address[1]))
    TCPClient.sendall(message.encode('utf-8'))
    print('Message is sent.')
    try:
        print('Receiving the response from the server')
        data = TCPClient.recv(bufferSize)
        data = data.decode('utf-8')
        isNewServerMsg = False
        return data
    except socket.timeout:
        print('Timeout occurred/No response from the server.')
        return None
    finally:
        TCPClient.close()
        
def TCP_Send(serverAddress, msg):
    response = client_send_and_receive(serverAddress, msg)  # Send the command to the server and receive the response
    msg = ''
    if response is not None:
        print('Data received:', response)
    

        
def serverMessageHandler(message):
    global RECEIVED_MESSAGES
    global RECEIVED_MESSAGE_DATA
    global isNewServerMsg
    global RECEIVED_DATA
    RECEIVED_MESSAGES += 1
    print("")
    print("Message received:")
    # print data from both system and application (custom) properties
    print("MsgType: ",str(vars(message)['message_id']),"\n")  
    RECEIVED_MESSAGE_DATA = vars(message)['data']
    RECEIVED_DATA = RECEIVED_MESSAGE_DATA.decode('utf-8')
    isNewServerMsg = True

# Thread definition 

class rb_fota_listenServerReq_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()

    def run(self):
        while True:
            # Instantiate the client
            client = IoTHubDeviceClient.create_from_connection_string(CONNECTION_STRING)
            serverAddress = ('192.168.0.123', 7)
            print ("Waiting for C2D messages")
            try:
                # Attach the handler to the client
                client.on_message_received = serverMessageHandler
                if isNewServerMsg == True:
                    TCP_Send(serverAddress,RECEIVED_DATA)
                sleep(3)
#             except KeyboardInterrupt:
            except :
                print("IoT Hub C2D Messaging device sample stopped")
            finally:
                # Graceful exit
                client.shutdown()
            time.sleep(1)
            self.signal.emit()
class rb_fota_checkPackageServer_thread(QThread):
    # Define a signal that will be emitted every 3 seconds
    signal = pyqtSignal()
    
    def run(self):             
        time.sleep(1)
        self.signal.emit()
#         except:

# Popup definition            
            
class newSwAvai_Popup(QtWidgets.QDialog):
    def __init__(self, isNewFWInstall):
        super().__init__()
        uic.loadUi(r'newSWImageExist.ui', self)
        self.FOTA_User_Yes.clicked.connect(self.on_yes_clicked)
        self.FOTA_User_No.clicked.connect(self.on_no_clicked)
        self.isNewFWInstall = isNewFWInstall

    def on_yes_clicked(self):
        global downloadFilePath
        print("o day thi sao",self.isNewFWInstall )
        # Add your code here for when the "Yes" button is clicked
        dialog = install2TECU_Popup(downloadFilePath, self.isNewFWInstall)
        dialog.valueUpdated.connect(self.handle_new_fw_install)      
        dialog.exec_()
        print("Yes button clicked")
        self.accept()  # Close the dialog
    def handle_new_fw_install(self, value):
        if value == "YES":
            global isNewFWInstall
            global userConfirm
            isNewFWInstall = "YES"
            userConfirm = False
            print("userConfirm: ",userConfirm)
            print("WHAT THE HELLL??????????????????? ",isNewFWInstall)
            
    def on_no_clicked(self):
        # Add your code here for when the "No" button is clicked
        print("No button clicked")
        self.reject()  # Close the dialog

# End New SW Available Popup

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.load_data_from_text_file('data.txt')
        
        self.rb_fota_listenServerReq_thread = rb_fota_listenServerReq_thread()
        self.rb_fota_checkPackageServer_thread = rb_fota_checkPackageServer_thread()

        
        self.rb_fota_listenServerReq_thread.signal.connect(self.on_listenServerReq_thread)
        self.rb_fota_checkPackageServer_thread.signal.connect(self.on_checkPakageServer_thread)

        
        self.rb_fota_listenServerReq_thread.start()
        self.rb_fota_checkPackageServer_thread.start()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.checkNewSwAvai)
        self.timer.start(10000) 
        
        self.timer1 = QTimer(self)
        self.timer1.timeout.connect(self.getBaseServerFileList)
        self.timer1.start(100)
        
        self.ui.icon_only_widget.hide()
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.home_btn_2.setChecked(True)
        
        self.ui.sendDiag.clicked.connect(self.getManualDiagMsg)
    def load_data_from_text_file(self, file_path):
        try:
            with open(file_path, 'r') as file:
                for line in file:
                    line = line.strip()
                    if line:
                        item = QListWidgetItem(line)
                        self.ui.listSwLog.addItem(item)
        except FileNotFoundError:
            print(f"File '{file_path}' not found.")
         
    def getManualDiagMsg(self):
        selectedUDSMsg = self.ui.DiagServices.currentText()
        UDS_payload = ""
        serverAddress = ('192.168.0.123', 7)
        if "10" in selectedUDSMsg[0:2]:
            UDS_payload = selectedUDSMsg[0:5].replace(" ","")
            UDS_msg = "".join(["UDS_",UDS_payload])
            UDS_display = "".join(["Send UDS request: ",UDS_msg])
            new_text = QListWidgetItem(UDS_display)
            self.ui.DiagResponse.addItem(new_text)
        else:
            UDS_payload = selectedUDSMsg[0:8].replace(" ","")
            UDS_msg = "".join(["UDS_",UDS_payload])
            UDS_display = "".join(["Send UDS request: ",UDS_msg])
            new_text = QListWidgetItem(UDS_display)
            self.ui.DiagResponse.addItem(new_text)
        response1 = client_send_and_receive(serverAddress,UDS_msg)
        sleep(1)
        response = client_send_and_receive(serverAddress,"UDS_GET")
        print("data la: ", response)
        UDS_display = "".join(["Reveive UDS Response: ",UDS_msg])
        new_text = QListWidgetItem(response)
        self.ui.DiagResponse.addItem(new_text)
        
        
    
        
    def checkNewSwAvai(self):
        global baseServerFileList
        global downloadFilePath
        global isNewSwAvai
        global isNewFWInstall
        checkServerContainerResult = get_file_from_cloud(baseServerFileList, isNewFWInstall)
        
        if checkServerContainerResult[1] != "":
            downloadFilePath = checkServerContainerResult[1]
            isNewFWInstall = checkServerContainerResult[2]
            print("file path: ",downloadFilePath )
            dialog = newSwAvai_Popup(isNewFWInstall)
            dialog.exec_()
        isNewSwAvai = checkServerContainerResult[-1]
        if isNewSwAvai == "YES":
            baseServerFileList = checkServerContainerResult[0] 
                 
    def getBaseServerFileList(self):
        global baseServerFileList 
        baseServerFileList = get_first_file_list()
        self.timer1.stop()
        
    @pyqtSlot()
    def on_listenServerReq_thread(self):
        print("thread 1")
        pass
    @pyqtSlot()
    def on_checkPakageServer_thread(self):
        pass
    @pyqtSlot()
    def on_sendServerRes_thread(self):
        print("Signal received from cyclic thread3!")
    ## Function for searching
    def on_search_btn_clicked(self):
        
        self.ui.stackedWidget.setCurrentIndex(5)
        search_text = self.ui.search_input.text().strip()
        if search_text:
            self.ui.label_9.setText(search_text)
            
 
    ## Function for changing page to user page
    def on_user_btn_clicked(self):
        self.ui.stackedWidget.setCurrentIndex(6)

    ## Change QPushButton Checkable status when stackedWidget index changed
    def on_stackedWidget_currentChanged(self, index):
        btn_list = self.ui.icon_only_widget.findChildren(QPushButton) \
                    + self.ui.full_menu_widget.findChildren(QPushButton)
        for btn in btn_list:
            if index in [5, 6]:
                btn.setAutoExclusive(False)
                btn.setChecked(False)
            else:
                btn.setAutoExclusive(True)
                
    ## functions for changing menu page
    def on_home_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(0)
    
    def on_home_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(0)

    def on_dashborad_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_dashborad_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def on_orders_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_orders_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def on_products_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_products_btn_2_toggled(self, ):
        self.ui.stackedWidget.setCurrentIndex(3)

    def on_customers_btn_1_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)

    def on_customers_btn_2_toggled(self):
        self.ui.stackedWidget.setCurrentIndex(4)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    style_file = QFile("style.qss")
    style_file.open(QFile.ReadOnly | QFile.Text)
    style_stream = QTextStream(style_file)
    app.setStyleSheet(style_stream.readAll())
    window = MainWindow()
    window.show()
    sys.exit(app.exec())




