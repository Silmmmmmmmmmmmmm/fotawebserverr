import socket
import time
from tftpy import TftpClient
from time import sleep
isFileTransferred = "NO"
# Sends a message to the server and receives the response over TCP.
def client_send_and_receive(server_address, message):
    bufferSize = 1024
    timeout = 5  # Set a timeout value of 5 seconds
    TCPClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Create a TCP socket
    TCPClient.settimeout(timeout)  # Set socket timeout
    TCPClient.connect(server_address)
    TCPClient.sendall(message.encode('utf-8'))
    try:
        data = TCPClient.recv(bufferSize)
        data = data.decode('utf-8')
        return data
    except socket.timeout:
        print('Timeout occurred/No response from the server.')
        return None
    finally:
        TCPClient.close()
def send_file_via_tftp(server_ip, local_file_path):
    print("Sending file...")
    try:
        # Open the local file in binary mode
        file = open(local_file_path, 'rb')
        
   
        # Create a TFTP client
        client = TftpClient(host=server_ip, port=69)
        client.options['blksize'] = 512  # Set the block size to the desired value
        client.options['tsize'] = len(file.read())  # Set the total file size

        # Reset the file position to the beginning
        file.seek(0)

        # Upload the file with retries on timeout
        retries = 2
        for attempt in range(retries):
            try:
                global isFileTransferred
                client.upload(local_file_path, file, timeout=10)
                isFileTransferred = "YES"
                print("File sent successful")
                return True  # Exit the function if the upload is successful
            except Exception as e:
                print(f"Attempt {attempt + 1}/{retries}: An error occurred: {str(e)}")
                print("Retrying in 5 seconds...")
                time.sleep(5)
                # Reset the file position to the beginning before retrying
                file.seek(0)
        
        print("Failed to send the file after multiple attempts.")
        return False
    except Exception as e:
        print(f"An error occurred: {str(e)}")
    finally:
        file.close()
def FOTA_TransferFileToAdapter(local_file_path):
    serverAddress = ('192.168.0.123', 7)
    server_ip = "192.168.0.123"
    global isFileTransferred
#     if "NO" == isFileTransferred :
    msg = "REQ_REPRO"
    if msg != '':  # Validate the message
        response = client_send_and_receive(serverAddress, msg)  # Send the command to the server and receive the response
        msg = ''
        if response is not None:  
            print('Data received:', response)
            if response == 'RES_REPRO_0':
                isFileTranfer = False
                while not isFileTranfer:
                    isFileTranfer = send_file_via_tftp(server_ip, local_file_path)
            response = ''
        else:
            print('Invalid or empty message.')

#         



